/*eslint angular/file-name: 0, no-undef: 0*/
(function() {
  'use strict';

  angular
    .module('app')
    .constant('pt-BR.i18n.models', {
      user: 'Usuário',
      task: 'Tarefa',
      project: 'Projeto'
    })

}());
